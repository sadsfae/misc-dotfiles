Credits
=======

``vim-python-pep8-indent`` has been originally written by **David Bustos** and **Eric Mc Sween** who both are unreachable unfortunately.

It is currently maintained by `Hynek Schlawack <https://twitter.com/hynek>`_ with the generous help of the following contributors:

- 0player
- Bryan Bennett
- Clay Gerrard
- Hassan Kibirige
- Jelte Fennema
- Johann Klähn
- Joseph Irwin
- Steve Losh
- Sylvain Soliman
